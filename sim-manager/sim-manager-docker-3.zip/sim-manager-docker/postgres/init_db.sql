-- ============================================================
--  SIM MANAGER — Initialisation de la base de données
-- ============================================================

-- Table des utilisateurs
CREATE TABLE IF NOT EXISTS users (
    id            SERIAL PRIMARY KEY,
    username      VARCHAR(50)  UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name     VARCHAR(150) NOT NULL,
    role          VARCHAR(20)  NOT NULL DEFAULT 'user'
                  CHECK (role IN ('admin','stock','livraison','consultation')),
    is_active     BOOLEAN      NOT NULL DEFAULT TRUE,
    last_login    TIMESTAMP,
    created_at    TIMESTAMP    DEFAULT NOW(),
    created_by    VARCHAR(50)
);

CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
CREATE INDEX IF NOT EXISTS idx_users_role     ON users(role);

-- Compte admin par défaut : admin / Admin@2025
-- (mot de passe à changer à la première connexion)
INSERT INTO users (username, password_hash, full_name, role, created_by)
VALUES (
  'admin',
  '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi',
  'Administrateur',
  'admin',
  'system'
) ON CONFLICT (username) DO NOTHING;

CREATE TABLE IF NOT EXISTS sim_cards (
    id            SERIAL PRIMARY KEY,
    iccid         VARCHAR(30) UNIQUE NOT NULL,
    operateur     VARCHAR(50) NOT NULL,
    lot           VARCHAR(100) NOT NULL,
    date_entree   DATE NOT NULL DEFAULT CURRENT_DATE,
    status        VARCHAR(20) NOT NULL DEFAULT 'disponible',
    livraison_ref VARCHAR(50),
    created_at    TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS livraisons (
    id             SERIAL PRIMARY KEY,
    ref            VARCHAR(50) UNIQUE NOT NULL,
    client         VARCHAR(150) NOT NULL,
    operateur      VARCHAR(50) NOT NULL,
    date_livraison DATE NOT NULL,
    quantite       INTEGER NOT NULL DEFAULT 0,
    created_at     TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS livraison_sims (
    id             SERIAL PRIMARY KEY,
    livraison_ref  VARCHAR(50) NOT NULL REFERENCES livraisons(ref) ON DELETE CASCADE,
    iccid          VARCHAR(30) NOT NULL REFERENCES sim_cards(iccid) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_sim_operateur ON sim_cards(operateur);
CREATE INDEX IF NOT EXISTS idx_sim_status    ON sim_cards(status);
CREATE INDEX IF NOT EXISTS idx_liv_ref       ON livraisons(ref);
